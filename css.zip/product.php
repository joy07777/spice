<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Clothing Store</title>
  <link rel="stylesheet" href="styless.css">
</head>
<body>
  <header>
    <h1>Products</h1>
  </header>
  <main>
    <section id="inventory_2">
      <!-- Product cards will be dynamically added here -->
    </section>
  </main>
  <script src="scriptss.js"></script>
</body>
</html>
