<?php
// Start session
session_start();

// Check if user is authenticated, if not, redirect to login page
if (!isset($_SESSION['authenticated']) || $_SESSION['authenticated'] !== TRUE) {
    header("Location: login.php");
    exit();
}

// Include database connection file
include("dbconn.php");

// Fetch user data for the sidebar
$user_email = $_SESSION['auth_user']['email'];


// Check if logout button is clicked
if (isset($_POST['logout'])) {
    // Destroy session
    session_unset();
    session_destroy();
    // Redirect to login page
    header("Location: index.php"); // home ang location depende sa inyo
    exit();
}