<?php

$conn = mysqli_connect("localhost", "root", "", "spice_db");

?>