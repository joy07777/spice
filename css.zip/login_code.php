<?php 
session_start();
include("dbconn.php");

if (isset($_POST["login_now"])) {
    if (!empty($_POST['email']) && !empty($_POST['password'])) {
        $email = $_POST['email'];
        $password = $_POST['password'];

        $login_query = "SELECT * FROM users WHERE email=? LIMIT 1";
        $stmt = $conn->prepare($login_query);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 1) {
            $row = $result->fetch_assoc();

            if (password_verify($password, $row['password'])) {
                $_SESSION['status'] = "You are Logged In Successfully!";
                $_SESSION['email'] = $row['email'];
                header("Location: indexx.html"); // Redirect to the dashboard
                exit();
            } else {
                $_SESSION['status2'] = "Invalid Email or Password";
            }
        } else {
            $_SESSION['status2'] = "Invalid Email or Password";
        }
    } else {
        $_SESSION['status2'] = "All fields are Mandatory";
    }
    header("Location: login.php");
    exit();
}
?>
